package local

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}
//local模式
object clusteranalyse {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setMaster("local").setAppName("analyse")
    val spark = new SparkContext(conf)
    val sparkSql = SparkSession.builder().master("local").appName("todf").getOrCreate()
    import sparkSql.implicits._
    val data = spark.textFile("data/用户分群/用户基本信息.csv")
    val data_res = data.map(line=>(line.split(",")(4),1)).filter(_._1!="渠道来源")
    data_res.reduceByKey(_+_).toDF().write.csv("output/用户分群/渠道饼图")
    sparkSql.stop()
    spark.stop()

  }
}
