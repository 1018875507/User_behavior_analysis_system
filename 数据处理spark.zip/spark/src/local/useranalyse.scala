package local

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}

object useranalyse {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setMaster("local").setAppName("time")
    val spark = new SparkContext(conf)
    val sparksql = SparkSession.builder()
      .master("local")
      .appName("tosql")
      .getOrCreate()
    import sparksql.implicits._
    val data = spark.textFile("data/用户分析/用户属性（新）.csv")
    val data_res = data.map(line=>(line.split(",")(4),1))
    data_res.cache()
    val res = data_res.reduceByKey(_+_)
    res.toDF().write.csv("output/用户分析/各个省份人数/")
    sparksql.stop()
    spark.stop()
  }
}
