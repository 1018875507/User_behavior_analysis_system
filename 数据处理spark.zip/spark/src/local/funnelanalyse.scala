package local

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}

object funnelanalyse {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setMaster("local").setAppName("event_anaylse")
    val spark = new SparkContext(conf)
    val sparksql = SparkSession.builder()
      .master("local")
      .appName("tosql")
      .getOrCreate()

    import sparksql.implicits._

    val data = spark.textFile("data/漏斗分析/商品购买过程.csv")
    val data_res = data.map(line=>(line.split(",")(0)
      ,line.split(",")(1)
      ,line.split(",")(2)
      ,line.split(",")(3)
      ,line.split(",")(4)
      ,line.split(",")(5)
      ,line.split(",")(6)))
      .filter(_._1!="时间")
    data_res.cache()
//    data_res.collect().foreach(println)
//
    val see_1 = data_res.map(line=>(line._1,line._4.toDouble)).reduceByKey(_+_)
      see_1.toDF().write.csv("output/漏斗分析/每天查看商品数量")
    val see_2 = data_res.map(line=>(line._1,line._5.toDouble)).reduceByKey(_+_)
      see_2.toDF().write.csv("output/漏斗分析/每天加入购物车数量")
    val see_3 =data_res.map(line=>(line._1,line._6.toDouble)).reduceByKey(_+_)
      see_3.toDF().write.csv("output/漏斗分析/每天生成订单数量")
    val see_4 = data_res.map(line=>(line._1,line._7.toDouble)).reduceByKey(_+_)
      see_4.toDF().write.csv("output/漏斗分析/每天付款数量")


    //see_1.join(see_2).join(see_3).join(see_4).collect().foreach(println)
    see_1.union(see_2).union(see_3).union(see_4).groupByKey().collect().foreach(println)
//    see_1.union(see_2).union(see_3).union(see_4).groupByKey()
//      .map(line=>(line._1,line._2.toList(0),line._2.toList(1),line._2.toList(2),line._2.toList(3)))
//      .toDF().write.csv("hdfs://master:9000/user/spark_design/output/tunnel_analyse/action_sum")

//
    val see_5 = see_1.union(see_2).reduceByKey((x,y)=>(y/x))
    see_5.toDF().write.csv("output/漏斗分析/每天_加入购物车/查看商品")
    val see_6 = see_2.union(see_3).reduceByKey((x,y)=>(y/x))
    see_6.toDF().write.csv("output/漏斗分析/每天_生成订单/加入购物车")
    val see_7 = see_3.union(see_4).reduceByKey((x,y)=>(y/x))
    see_7.toDF().write.csv("output/漏斗分析/每天_付款/生成订单")

    val see_8 = see_1.map(line=>(line._2)).reduce(_+_)  //查看商品详情总数
    val see_9 = see_2.map(line=>(line._2)).reduce(_+_)  //加入购物车总数
    val see_10 = see_3.map(line=>(line._2)).reduce(_+_) //生成订单总数
    val see_11 = see_4.map(line=>(line._2)).reduce(_+_) //付款总数

    val see_12 = see_9/see_8
    val see_13 = see_10/see_9
    val see_14 = see_11/see_10
//
//    val res = spark.parallelize(List(see_8,see_9,see_10,see_11,see_12,see_13,see_14))
//    res.toDF().write.csv("hdfs://master:9000/user/spark_design/output/tunnel_analyse/res_number")
    println("查看商品总数： " + see_8)
    println("加入购物车总数： " + see_9)
    println("生成订单总数： " + see_10)
    println("付款总数： " + see_11)
//
    println("加入购物车/查看商品： " + see_12)
    println("生成订单商品/加入购物车： " + see_13)
    println("付款数/生成订单： " + see_14)
  }
}
