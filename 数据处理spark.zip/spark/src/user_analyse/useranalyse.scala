package user_analyse

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}

object useranalyse {
  def main(args: Array[String]): Unit = {
    val Conf = new SparkConf().setAppName("test")
      .setMaster("spark://master:7077")
      .setJars(Seq("E:\\Users\\hanlx\\Desktop\\scala_pro\\target\\sparkdemo-1.0-SNAPSHOT.jar"))
      .setIfMissing("spark.driver.host","192.168.19.180")
    val spark = new SparkContext(Conf)
    val sparksql = SparkSession.builder()
      .master("local")
      .appName("tosql")
      .getOrCreate()

    val data = spark.textFile("hdfs://master:9000/user/spark_design/input/data/user_anaylse/user_attribute.csv")
    import sparksql.implicits._
 //   data.cache()
 //   val data = spark.textFile("data/用户分析/用户属性（新）.csv")
    val data_res = data.map(line=>(line.split(",")(4),1))
    data_res.cache()
    val res = data_res.reduceByKey(_+_)
    res.toDF().write.csv("hdfs://master:9000/user/spark_design/output/user_anaylse/")
    sparksql.stop()
    spark.stop()
  }
}
