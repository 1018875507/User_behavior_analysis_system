package FullBehavior

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.{SparkConf, SparkContext}

object time {
  def main(args: Array[String]): Unit = {
//    println("hello world")
//    val conf = new SparkConf().setMaster("local").setAppName("time")
//    val spark = new SparkContext(conf)
//    spark.setLogLevel("WARN")
//    val data = spark.textFile("data/全行为路径分析/注册用户全行为路径.csv")

//    val sparksql = SparkSession.builder()
//      .master("local")
//      .appName("tosql")
//      .getOrCreate()

    val Conf = new SparkConf().setAppName("test")
      .setMaster("spark://master:7077")
      .setJars(Seq("E:\\Users\\hanlx\\Desktop\\scala_pro\\target\\spark_pro-1.0-SNAPSHOT.jar"))
      .setIfMissing("spark.driver.host","192.168.19.180")
    val spark = new SparkContext(Conf)
    val sparksql = SparkSession.builder()
      .master("local")
      .appName("tosql")
      .getOrCreate()

    val data = spark.textFile("hdfs://master:9000/user/spark_design/input/data/all_behavior_analyse/all_behavior_path.csv")
    import sparksql.implicits._
    data.cache()

    val data_split = data.map(
      line=>(line.split(",")(0).replaceAll("/","-"),
        line.split(",")(1),
        line.split(",")(2),
        line.split(",")(3),
        line.split(",")(4),
        line.split(",")(5),
        line.split(",")(6),
        line.split(",")(7)))
     val data_res = data_split.filter(_._1!="日期")   //分割结束
    //data_res.collect().foreach(println)

    //各个行为数量计算
    val b1 = data_res.map(line=>(line._2,Integer.parseInt(line._8.trim)))
    val b2 = data_res.map(line=>(line._3,Integer.parseInt(line._8.trim)))
    val b3 = data_res.map(line=>(line._4,Integer.parseInt(line._8.trim)))
    val b4 = data_res.map(line=>(line._5,Integer.parseInt(line._8.trim)))
    val b5 = data_res.map(line=>(line._6,Integer.parseInt(line._8.trim)))
    val b6 = data_res.map(line=>(line._7,Integer.parseInt(line._8.trim)))
    val b1_1 = b1.reduceByKey(_+_)
    val b2_1 = b2.reduceByKey(_+_)
    val b3_1 = b3.reduceByKey(_+_)
    val b4_1 = b4.reduceByKey(_+_)
    val b5_1 = b5.reduceByKey(_+_)
    val b6_1 = b6.reduceByKey(_+_)
    val b1_11 = b1_1.union(b2_1).union(b3_1).union(b4_1).union(b5_1).union(b5_1).union(b6_1)

    b1_11.reduceByKey(_+_).filter(_._1!="").toDF().write.csv("hdfs://master:9000/user/spark_design/output/all_behavior_analyse/")





//        // TODO: 按时间划分每天的活动人数
//    val data_time = data_res.map(x=>(x._1,x._8.toInt))
//    val date_time_res = data_time.reduceByKey(_+_);
//    date_time_res.collect().foreach(println)
//    date_time_res.toDF().write.csv("output/全行为/每天活动人数/")

//
//// TODO: 注册成功和失败人数
//    val register_num = data_res.map(x=>(x._3,x._8.toInt))
//    val register_num_res = register_num.reduceByKey(_+_)
//    register_num_res.collect().foreach(println)
//    register_num_res.toDF().write.csv("output/全行为/注册环节/")
//
//    // TODO: 登录环节成功和失败人数
//    val siagup_num = data_res.map(x=>(x._4,x._8.toInt))
//    val signup_num_res = siagup_num.reduceByKey(_+_)
//    signup_num_res.collect().foreach(println)
//    signup_num_res.toDF().write.csv("output/全行为/登录环节/")
//
//    // TODO: 登录环节成功和失败人数
//    val course = data_res.map(x=>(x._4,x._8.toInt))
//    val course_num = course.reduceByKey(_+_)
//    course_num.collect().foreach(println)
//    course_num.toDF().write.csv("output/全行为/课程操作环节/")
    sparksql.stop()
    spark.stop()
  }

}
