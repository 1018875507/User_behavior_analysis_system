package FullBehavior

import org.apache.spark.sql.{DataFrame, SparkSession}

object jdbc {
  def main(args: Array[String]): Unit = {
    val spark = new SparkSession.Builder()
      .master("local")
      .appName("tosql")
      .getOrCreate()

    val df:DataFrame =spark.read.format("jdbc")
      .option("url","jdbc:mysql://127.0.0.1:3306/spark_de")
      .option("driver","com.mysql.jdbc.Driver")
      .option("user","root")
      .option("password", "123456")
      .option("dbtable","event_analyse")
      .load()
    df.groupBy(df("province"),df("first_sou")).count().show()



  }

}
