package userClustering

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}

object clusteranalyse {
  def main(args: Array[String]): Unit = {
//    val conf = new SparkConf().setMaster("local").setAppName("analyse")
//    val spark = new SparkContext(conf)
//    val sparkSql = SparkSession.builder().master("local").appName("todf").getOrCreate()
//    import sparkSql.implicits._
//    val data = spark.textFile("data/用户分群/用户基本信息.csv")
val Conf = new SparkConf().setAppName("test")
  .setMaster("spark://master:7077")
  .setJars(Seq("E:\\Users\\hanlx\\Desktop\\scala_pro\\target\\spark_pro-1.0-SNAPSHOT.jar"))
  .setIfMissing("spark.driver.host","192.168.130.180")
    val spark = new SparkContext(Conf)
    val sparksql = SparkSession.builder()
      .master("local")
      .appName("tosql")
      .getOrCreate()

    val data = spark.textFile("hdfs://master:9000/user/spark_design/input/data/cluster_user/user_imformation.csv")
    import sparksql.implicits._
    val data_res = data.map(line=>(line.split(",")(4),1)).filter(_._1!="渠道来源")
//    data_res.reduceByKey(_+_).toDF().write.csv("output/用户分群/渠道饼图")
    data_res.reduceByKey(_+_).toDF().write.csv("hdfs://master:9000/user/spark_design/output/cluster_user")
    sparksql.stop()
    spark.stop()

  }
}
