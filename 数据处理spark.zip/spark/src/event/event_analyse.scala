package event

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}

object event_analyse {
  def main(args: Array[String]): Unit = {
//    val conf = new SparkConf().setMaster("local").setAppName("event_anaylse")
//    val spark = new SparkContext(conf)
//    val data = spark.textFile("data/事件分析/用户属性信息.csv")

    val Conf = new SparkConf().setAppName("test")
      .setMaster("spark://192.168.60.130:7077")
      .setJars(Seq("D:\\IdeaProjects\\spark\\target\\spark-1.0-SNAPSHOT.jar"))
      .setIfMissing("spark.driver.host","172.32.173.193")
    val spark = new SparkContext(Conf)
    val sparksql = SparkSession.builder()
      .master("local")
      .appName("tosql")
      .getOrCreate()

    val data = spark.textFile("hdfs://192.168.60.130:9000/test/data/事件分析/用户属性信息.csv")
    import sparksql.implicits._
    data.cache()

    // TODO: 每日访问人数
    val time_num = data.map(line => (line.split(",")(5), 1))
    val time_num_res = time_num.filter(_._1 != "首次访问时间").reduceByKey(_ + _)
    //time_num_res.toDF().write.csv("output/event_analyse/day_number/")
    time_num_res.toDF().write.csv("hdfs://192.168.60.130:9000/test/output/event/user_attribute/time_number")

//
    //todo: 各个省份人数
    val province_num = data.map(line => (line.split(",")(3), 1))
    val province_num_res = province_num.filter(_._1 != "省份").reduceByKey(_ + _)
    //    province_num_res.collect().foreach(println)
    province_num_res.toDF().write.csv("hdfs://192.168.60.130:9000/test/output/event/user_attribute/province_number")
//
    //todo: 各个性别人数
    val sex_num = data.map(line => (line.split(",")(2), 1))
    val sex_num_res = sex_num.filter(_._1 != "性别").reduceByKey(_ + _)
    //    sex_num_res.collect().foreach(println)
    sex_num_res.toDF().write.csv("hdfs://192.168.60.130:9000/test/event/user_attribute/sex_number")

    //todo: 各个职业人数
    val career_num = data.map(line => (line.split(",")(4), 1))
    val career_num_res = career_num.filter(_._1 != "首次搜索引擎关键词").reduceByKey(_ + _)
    //    career_num_res.collect().foreach(println)
    career_num_res.toDF().write.csv("hdfs://192.168.60.130:9000/test/output/event/user_attribute/career_number")

    sparksql.stop()
    spark.stop()

  }
}
